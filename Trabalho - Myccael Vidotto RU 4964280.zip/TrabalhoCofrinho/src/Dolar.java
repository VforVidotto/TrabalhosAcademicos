/*
 * Aluno: Myccael Cesar Vidotto
 * RU: 4964280
 * Curso: Análise e Desenvolvimento de Sistemas - UNINTER
 */

// Classe do Dólar, também herda da classe Moeda
public class Dolar extends Moeda {

    public Dolar(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Dólar - $ " + this.valor);
    }

    @Override
    public double converter() {
        // Converte para Real usando uma cotação fixa de 5.0
        return this.valor * 5.0; 
    }
}