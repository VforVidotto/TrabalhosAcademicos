/*
 * Aluno: Myccael Cesar Vidotto
 * RU: 4964280
 * Curso: Análise e Desenvolvimento de Sistemas - UNINTER
 */

// Classe da moeda Real, que herda da classe abstrata Moeda
public class Real extends Moeda {
	
    public Real(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Real - R$ " + this.valor);
    }

    @Override
    public double converter() {
        // Como a moeda já tá em Real, só retorna o próprio valor sem multiplicar por nada
        return this.valor;
    }
}