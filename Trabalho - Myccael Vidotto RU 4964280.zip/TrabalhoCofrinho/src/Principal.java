/*
 * Aluno: Myccael Cesar Vidotto
 * RU: 4964280
 * Curso: Análise e Desenvolvimento de Sistemas - UNINTER
 */

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();
        int opcao = 0;

        // Loop principal do menu, roda até o usuário escolher sair (opção 5)
        while (opcao != 5) {
            System.out.println("\n--- MENU COFRINHO ---");
            System.out.println("1 - Adicionar Moeda");
            System.out.println("2 - Remover Moeda");
            System.out.println("3 - Listar Moedas");
            System.out.println("4 - Calcular Total Convertido para Real");
            System.out.println("5 - Encerrar");
            System.out.print("Escolha uma opção: ");
            
            opcao = teclado.nextInt();
            int tipoMoeda;
            double valorMoeda;
            Moeda moeda = null;

            switch (opcao) {
                case 1:
                    // Submenu para escolher o tipo da moeda a adicionar
                    System.out.println("1 - Real | 2 - Dólar | 3 - Euro");
                    System.out.print("Escolha a moeda: ");
                    tipoMoeda = teclado.nextInt();
                    System.out.print("Digite o valor: ");
                    valorMoeda = teclado.nextDouble();
                    
                    // Instancia a moeda de acordo com a escolha do usuário
                    if (tipoMoeda == 1) {
                        moeda = new Real(valorMoeda);
                    } else if (tipoMoeda == 2) {
                        moeda = new Dolar(valorMoeda);
                    } else if (tipoMoeda == 3) {
                        moeda = new Euro(valorMoeda);
                    } else {
                        System.out.println("Tipo de moeda inválido!");
                        continue;
                    }
                    cofrinho.adicionar(moeda);
                    System.out.println("Moeda adicionada ao cofrinho!");
                    break;
                    
                case 2:
                    // Submenu para escolher o tipo da moeda a remover
                    System.out.println("1 - Real | 2 - Dólar | 3 - Euro");
                    System.out.print("Escolha a moeda a remover: ");
                    tipoMoeda = teclado.nextInt();
                    System.out.print("Digite o valor da moeda a remover: ");
                    valorMoeda = teclado.nextDouble();
                    
                    if (tipoMoeda == 1) {
                        moeda = new Real(valorMoeda);
                    } else if (tipoMoeda == 2) {
                        moeda = new Dolar(valorMoeda);
                    } else if (tipoMoeda == 3) {
                        moeda = new Euro(valorMoeda);
                    } else {
                        System.out.println("Tipo de moeda inválido!");
                        continue;
                    }
                    cofrinho.remover(moeda);
                    break;
                    
                case 3:
                    // Lista todas as moedas
                    System.out.println("\n--- MOEDAS NO COFRINHO ---");
                    cofrinho.listagemMoedas();
                    break;
                    
                case 4:
                    // Mostra o total convertido em Reais
                    double valorTotal = cofrinho.totalConvertido();
                    System.out.printf("\nO valor total convertido para Reais é: R$ %.2f\n", valorTotal);
                    break;
                    
                case 5:
                    System.out.println("Encerrando o sistema...");
                    break;
                    
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }
        }
        teclado.close();
    }
}