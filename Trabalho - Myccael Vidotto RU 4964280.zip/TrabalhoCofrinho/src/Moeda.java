/*
 * Aluno: Myccael Cesar Vidotto
 * RU: 4964280
 * Curso: Análise e Desenvolvimento de Sistemas - UNINTER
 */

public abstract class Moeda {
    // Guarda o valor da moeda. O protected permite que as classes filhas usem essa variável
    protected double valor;

    public Moeda(double valor) {
        this.valor = valor;
    }

    // Métodos abstratos: quem herdar desta classe vai ter que implementar a sua própria versão
    public abstract void info();
    public abstract double converter();

    // Sobrescrevemos o equals para comparar moedas pelo tipo e pelo valor
    // Isso é essencial para o método de remover da lista funcionar direitinho
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Moeda other = (Moeda) obj;
        return Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
    }
}