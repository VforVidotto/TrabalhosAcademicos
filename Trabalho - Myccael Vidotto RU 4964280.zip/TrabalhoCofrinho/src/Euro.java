/*
 * Aluno: Myccael Cesar Vidotto
 * RU: 4964280
 * Curso: Análise e Desenvolvimento de Sistemas - UNINTER
 */

// Classe do Euro, herda da classe Moeda
public class Euro extends Moeda {

    public Euro(double valor) {
        super(valor);
    }

    @Override
    public void info() {
        System.out.println("Euro - € " + this.valor);
    }

    @Override
    public double converter() {
        // Converte para Real usando uma cotação fixa de 5.5
        return this.valor * 5.5; 
    }
}