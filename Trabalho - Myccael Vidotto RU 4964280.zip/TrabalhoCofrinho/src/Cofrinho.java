/*
 * Aluno: Myccael Cesar Vidotto
 * RU: 4964280
 * Curso: Análise e Desenvolvimento de Sistemas - UNINTER
 */

import java.util.ArrayList;

public class Cofrinho {
    // Lista genérica que guarda qualquer tipo de moeda.
    private ArrayList<Moeda> listaMoedas;

    public Cofrinho() {
        this.listaMoedas = new ArrayList<>();
    }

    // Adiciona uma nova moeda na lista.
    public void adicionar(Moeda moeda) {
        this.listaMoedas.add(moeda);
    }

    // Procura e remove moeda da lista. Usa o equals() da classe Moeda
    public void remover(Moeda moeda) {
        boolean removido = this.listaMoedas.remove(moeda);
        if (removido) {
            System.out.println("Moeda removida com sucesso!");
        } else {
            System.out.println("Moeda não encontrada no cofrinho.");
        }
    }

    // Percorre a lista e exibe as informações de cada moeda
    public void listagemMoedas() {
        if (this.listaMoedas.isEmpty()) {
            System.out.println("O cofrinho está vazio.");
            return;
        }
        for (Moeda moeda : this.listaMoedas) {
            moeda.info(); // Polimorfismo: chama o info() específico de cada moeda
        }
    }

    // Soma o valor de todas as moedas em Real
    public double totalConvertido() {
        double total = 0;
        for (Moeda moeda : this.listaMoedas) {
            total += moeda.converter(); // Polimorfismo: cada moeda aplica a sua regra de conversão
        }
        return total;
    }
}